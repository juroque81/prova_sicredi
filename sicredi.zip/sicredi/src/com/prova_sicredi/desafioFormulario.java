package com.prova_sicredi;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.fail;

public class desafioFormulario {

    public WebDriver driver;

    @Before
    public void setUp() throws Exception {
        System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
        driver.get("https://www.grocerycrud.com/demo/bootstrap_theme");
        driver.manage().window().setSize(new Dimension(1382, 744));
    }

    @After
    public void tearDown() throws Exception {
        driver.quit();
    }

    @Test
    public void CT001ValidarCamposObrigatoriosLogin() {

        Select addCustomer = new Select(driver.findElement(By.id("switch-version-select")));
        addCustomer.selectByVisibleText("Bootstrap V4 Theme");

        driver.findElement(By.linkText("Add Customer")).click();

        WebElement name = driver.findElement(By.id("field-customerName"));
        name.sendKeys("Teste Sicredi");

        WebElement lastName = driver.findElement(By.id("field-contactLastName"));
        lastName.sendKeys("Teste");

        WebElement contactFirstName = driver.findElement(By.id("field-contactFirstName"));
        contactFirstName.sendKeys("Juliana");

        WebElement phone = driver.findElement(By.id("field-phone"));
        phone.sendKeys("51 9999-9999");

        WebElement addressLine1 = driver.findElement(By.id("field-addressLine1"));
        addressLine1.sendKeys("Av Assis Brasil, 3970");

        WebElement addressLine2 = driver.findElement(By.id("field-addressLine2"));
        addressLine2.sendKeys("Torre D");

        WebElement city = driver.findElement(By.id("field-city"));
        city.sendKeys("Porto Alegre");

        WebElement state = driver.findElement(By.id("field-state"));
        state.sendKeys("RS");

        WebElement postalCode = driver.findElement(By.id("field-postalCode"));
        postalCode.sendKeys("91000-000");

        WebElement country = driver.findElement(By.id("field-country"));
        country.sendKeys("Brasil");

        driver.findElement(By.cssSelector("span")).click();
        driver.findElement(By.cssSelector("span")).click();
        driver.findElement(By.cssSelector(".chosen-search > input")).click();
        driver.findElement(By.cssSelector(".chosen-search > input")).sendKeys("Fixter");
        driver.findElement(By.cssSelector("em")).click();

        driver.findElement(By.id("field-creditLimit")).click();
        driver.findElement(By.id("field-creditLimit")).sendKeys("200");

        driver.findElement(By.id("form-button-save")).click();

        for (int second = 0; ; second++) {
            if (second >= 120) {
                fail("timeout");
            }
            try {
                if ("Your data has been successfully stored into the database. Edit Customer or Go back to list".equals(driver.findElement(By.cssSelector("p")).getText())) {
                    System.out.println("Cadastro concluído com sucesso!");
                    break;
                }
            } catch (Exception e) {
            }
        }

        driver.findElement(By.linkText("Go back to list")).click();

        System.out.println("Acesso link Go back to list com sucesso!");

        WebElement colunaName = driver.findElement(By.name("customerName"));
        colunaName.sendKeys("Teste Sicredi");

        driver.findElement(By.cssSelector(".select-row")).click();

        driver.findElement(By.linkText("Delete")).click();

        for (int second = 0; ; second++) {
            if (second >= 120) {
                fail("timeout");
            }
            try {
                if ("Are you sure that you want to delete this 1 item?".equals(driver.findElement(By.cssSelector(".alert-delete-multiple-one")).getText())) {
                    System.out.println("Confirmação da exclusão!");
                    break;
                }
            } catch (Exception e) {
            }
        }

        driver.findElement(By.cssSelector(".delete-multiple-confirmation-button")).click();

        for (int second = 0; ; second++) {
            if (second >= 120) {
                fail("timeout");
            }
            try {
                if ("Your data has been successfully deleted from the database.".equals(driver.findElement(By.cssSelector("span > p")).getText())) {
                    System.out.println("Cadastro excluído com sucesso!");
                    break;
                }
            } catch (Exception e) {
            }
        }
    }
}


